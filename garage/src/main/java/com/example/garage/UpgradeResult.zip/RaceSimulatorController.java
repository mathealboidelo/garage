package com.example.garage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Random;

/**
 * ══════════════════════════════════════════════════════════════
 *  RACE SIMULATION ENGINE v2 — Street Racer
 * ══════════════════════════════════════════════════════════════
 *  Gère : mise en crédits, pari voiture, réputation,
 *         usure pneus/huile, système gang/boss,
 *         adversaires spéciaux.
 * ══════════════════════════════════════════════════════════════
 */
@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class RaceSimulatorController {

    @Autowired private UserRepository         userRepo;
    @Autowired private RacersRepository       racersRepo;
    @Autowired private RaceRepository         raceRepo;
    @Autowired private CarRepository          carRepo;
    @Autowired private DealershipRepository   dealerRepo;
    @Autowired private UserProgressRepository progressRepo;

    private static final Random RNG = new Random();

    // Usure par course (en %)
    private static final double TIRE_WEAR_PER_RACE = 8.0;
    private static final double OIL_DECAY_PER_RACE = 5.0;

    // Réputation gagnée par victoire selon type d'adversaire
    private static final int REP_WIN_NORMAL  = 10;
    private static final int REP_WIN_GANG    = 20;
    private static final int REP_WIN_BOSS    = 50;
    private static final int REP_WIN_SPECIAL = 35;

    @PostMapping("/api/race/run")
    public ResponseEntity<?> runRace(@RequestBody RaceRequest req) {

        User user = userRepo.findById(req.userId())
                .orElseThrow(() -> new RuntimeException("Joueur introuvable"));
        Racers opponent = racersRepo.findById(req.opponentId())
                .orElseThrow(() -> new RuntimeException("Adversaire introuvable"));
        Race race = raceRepo.findById(req.raceId())
                .orElseThrow(() -> new RuntimeException("Circuit introuvable"));

        // ── Validation ────────────────────────────────────
        if (!req.betCar() && user.getCredits() < req.bet()) {
            return ResponseEntity.badRequest().body("Pas assez de credits !");
        }
        if (user.getGarage() == null || user.getGarage().getCars().isEmpty()) {
            return ResponseEntity.badRequest().body("Aucune voiture dans le garage !");
        }

        // ── Voiture du joueur ─────────────────────────────
        Car playerCar = user.getGarage().getCars().stream()
                .filter(c -> c.getId().equals(req.carId()))
                .findFirst()
                .orElse(user.getGarage().getCars().get(0));

        // ── Vérification pari voiture ─────────────────────
        Car wageredCar = null;
        if (req.betCar()) {
            wageredCar = user.getGarage().getCars().stream()
                    .filter(c -> c.getId().equals(req.carId()))
                    .findFirst().orElse(null);
            if (wageredCar == null) {
                return ResponseEntity.badRequest().body("Voiture mise en jeu introuvable !");
            }
            if (user.getGarage().getCars().size() < 2) {
                return ResponseEntity.badRequest().body("Tu ne peux pas miser ta seule voiture !");
            }
        }

        // ── Score ─────────────────────────────────────────
        double sr = race.getStraigthLine() / 100.0;
        double cr = race.getCorner()       / 100.0;

        double playerScore   = computeScore(playerCar, sr, cr);
        double opponentScore = computeScore(opponent.getCar(), sr, cr);

        boolean won = playerScore > opponentScore;

        // ── UserProgress ──────────────────────────────────
        UserProgress progress = progressRepo.findByUserId(user.getId()).orElseGet(() -> {
            UserProgress p = new UserProgress();
            p.setUser(user);
            return progressRepo.save(p);
        });

        // ── Usure pneus / huile ───────────────────────────
        double newTire = Math.max(0, playerCar.getTireWear() - TIRE_WEAR_PER_RACE);
        double newOil  = Math.max(0, playerCar.getOilQuality() - OIL_DECAY_PER_RACE);
        playerCar.setTireWear(newTire);
        playerCar.setOilQuality(newOil);
        playerCar.setRacesCount(playerCar.getRacesCount() + 1);

        // ── Transaction financière ─────────────────────────
        long creditsChange = 0;
        boolean lostCar    = false;
        String wonCarName  = null;

        if (req.betCar()) {
            if (won) {
                // Gagne la voiture de l'adversaire (copie depuis la DB opponent)
                Car opCar = opponent.getCar();
                Car prize = cloneCar(opCar, user.getGarage());
                carRepo.save(prize);
                wonCarName = opCar.getName();
            } else {
                // Perd sa voiture
                Car lost = wageredCar;
                lost.setGarage(null);
                carRepo.save(lost);
                lostCar = true;
            }
        } else {
            creditsChange = won ? req.bet() : -req.bet();
            user.setCredits(user.getCredits() + creditsChange);
        }

        // ── Réputation & victoires ─────────────────────────
        int repEarned = 0;
        boolean gangMemberDefeated = false;
        boolean bossDefeated       = false;
        boolean specialCarUnlocked = false;
        String  specialCarName     = null;
        long    specialCarId       = 0;

        if (won) {
            user.setWins(user.getWins() + 1);

            if (opponent.isSpecial()) {
                repEarned = REP_WIN_SPECIAL;
                // Mettre la voiture spéciale en vente au premier concessionnaire trouvé
                if (opponent.getSpecialCarForSale() != null) {
                    Car sc = opponent.getSpecialCarForSale();
                    // Cherche le dernier concessionnaire (Legend Motorsport) pour y mettre la voiture
                    List<Dealership> dealers = dealerRepo.findAll();
                    if (!dealers.isEmpty()) {
                        Dealership target = dealers.get(dealers.size() - 1);
                        sc.setDealership(target);
                        sc.setGarage(null);
                        carRepo.save(sc);
                        specialCarUnlocked = true;
                        specialCarName     = sc.getName();
                        specialCarId       = sc.getId();
                    }
                }
            } else if (opponent.isBoss()) {
                repEarned = REP_WIN_BOSS;
                bossDefeated = true;
                progress.addDefeated(opponent.getId());
            } else if (opponent.isGangMember()) {
                repEarned = REP_WIN_GANG;
                gangMemberDefeated = true;
                progress.addDefeated(opponent.getId());
            } else {
                repEarned = REP_WIN_NORMAL;
            }
            user.setReputation(user.getReputation() + repEarned);

            // Montée de niveau : 1 niveau tous les 500 de réputation
            int newLevel = 1 + user.getReputation() / 500;
            user.setLevel(Math.min(newLevel, 99));
        }

        // ── Sauvegarde ────────────────────────────────────
        carRepo.save(playerCar);
        userRepo.save(user);
        progressRepo.save(progress);

        // ── Construction du résultat ──────────────────────
        RaceResult result = new RaceResult();
        result.setPlayerWon(won);
        result.setPlayerName(user.getUsername());
        result.setOpponentName(opponent.getDisplayName());
        result.setRaceName(race.getName());
        result.setPlayerScore(r2(playerScore));
        result.setOpponentScore(r2(opponentScore));
        result.setCreditsEarned(creditsChange);
        result.setNewBalance(user.getCredits());
        result.setReputationEarned(repEarned);
        result.setNewReputation(user.getReputation());
        result.setNewTireWear(r2(newTire));
        result.setNewOilQuality(r2(newOil));
        result.setGangMemberDefeated(gangMemberDefeated);
        result.setBossDefeated(bossDefeated);
        result.setCarWager(req.betCar());
        result.setWonCarName(wonCarName);
        result.setLostCar(lostCar);
        result.setSpecialCarUnlocked(specialCarUnlocked);
        result.setSpecialCarName(specialCarName);
        result.setSpecialCarId(specialCarId);
        result.setResultMessage(buildMsg(won, opponent.getDisplayName(), race.getName(), playerScore, opponentScore));

        return ResponseEntity.ok(result);
    }

    // ── Formule de simulation ─────────────────────────────
    private double computeScore(Car car, double sr, double cr) {
        // Usure pneus : pénalité progressive (0% wear = -20% grip)
        double tireMulti = 0.80 + (car.getTireWear() / 100.0) * 0.20;

        // Qualité huile : pénalité sur la puissance
        double oilMulti = 0.85 + (car.getOilQuality() / 100.0) * 0.15;

        double aspBonus = "TURBO".equalsIgnoreCase(car.getAspiration().name()) ? 1.15 : 1.0;
        double straight = (car.getPower() * oilMulti / car.getWeight()) * aspBonus * 100.0;
        double corner   = car.getGripModifier() * tireMulti * tireCoeff(car.getTireType()) * (1000.0 / car.getWeight()) * 100.0;
        double base     = sr * straight + cr * corner;
        double noise    = clamp(1.0 + RNG.nextGaussian() * 0.08, 0.88, 1.12);
        return base * noise;
    }

    private double tireCoeff(String t) {
        if (t == null) return 1.0;
        return switch (t.toLowerCase()) {
            case "slick"      -> 1.20;
            case "semi-slick" -> 1.10;
            case "rain"       -> 0.85;
            default           -> 1.00;
        };
    }

    private Car cloneCar(Car src, Garage dest) {
        Car c = new Car();
        c.setName(src.getName()); c.setPower(src.getPower()); c.setWeight(src.getWeight());
        c.setGripModifier(src.getGripModifier()); c.setAspiration(src.getAspiration());
        c.setTireType(src.getTireType()); c.setPrice(src.getPrice());
        c.setGarage(dest); c.setDealership(null);
        c.setTireWear(100.0); c.setOilQuality(100.0);
        return c;
    }

    private double clamp(double v, double lo, double hi) { return Math.max(lo, Math.min(hi, v)); }
    private double r2(double v) { return Math.round(v * 100.0) / 100.0; }

    private String buildMsg(boolean won, String opp, String race, double ps, double os) {
        String d = String.format("%.1f", Math.abs(ps - os));
        return won
            ? String.format("Victoire sur %s ! Score %.1f vs %.1f (+%s)", race, ps, os, d)
            : String.format("Defaite sur %s. Score %.1f vs %.1f (-%s)", race, ps, os, d);
    }
}
