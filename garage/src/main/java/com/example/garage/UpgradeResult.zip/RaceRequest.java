package com.example.garage;

/**
 * Payload pour lancer une course.
 *  betCar  : true = on mise sa voiture (wagerCarId = voiture mise en jeu adverse)
 */
public record RaceRequest(
    long    userId,
    long    carId,
    long    opponentId,
    long    raceId,
    long    bet,
    boolean betCar,
    long    wagerCarId   // id de la voiture adverse mise en jeu (0 si pas de pari voiture)
) {}
